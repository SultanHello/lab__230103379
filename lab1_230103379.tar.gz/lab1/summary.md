# Lab 1 results

All reported averages discard run 1 (cold/warm-up) and average runs 2 and 3.

## Baseline and scaling

| k | Avg runtime (s) | Empirical speedup | Amdahl speedup | Reality gap |
|---:|---:|---:|---:|---:|
| 1 | 1.631344 | 1.0100 | 1.0000 | -0.0100 |
| 2 | 0.871094 | 1.8914 | 1.8914 | 0.0000 |
| 4 | 0.477274 | 3.4521 | 3.4123 | -0.0398 |
| 8 | 0.299301 | 5.5048 | 5.7067 | 0.2019 |

Sequential baseline T_seq = 1.647604 s.
Derived parallel fraction from k=2: p = 0.942593.

## False-sharing experiment at 8 threads

| Variant | Avg runtime (s) | Throughput (iter/s) | Naive/mitigated time ratio |
|---|---:|---:|---:|
| Naive per-thread array | 0.345444 | 38729911 | 1.1334 |
| OpenMP reduction | 0.304796 | 43894867 | 1.1334 |

## Scheduling experiment at 8 threads

| Scheduling clause | Avg runtime (s) |
|---|---:|
| static | 0.302276 |
| static,1000 | 0.304546 |
| dynamic,100 | 0.284260 |
| dynamic,10000 | 0.287156 |
| guided | 0.281572 |

## Integrity checks

max_steps: ['688']
checksum: ['117734093']
hits (>100 steps): ['10796034']
